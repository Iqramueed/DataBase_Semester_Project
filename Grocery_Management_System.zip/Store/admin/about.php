<!DOCTYPE html>
<html>
<head>
	<title>
		Grocery Management System
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<style type="text/css">
	nav
	{
		float: right;
		word-spacing: 30px;
		padding: 20px;
	}
	nav li 
	{
		display: inline-block;
		line-height: 80px;
	}
</style>
</head>


<body>
	<div class="wrapper">
		<header>
			<div class="logo">
      <h1 style="color: white; font-size: 22px;word-spacing: 20px; line-height: 30px;margin-top: 3px;">GROCERY MANAGEMENT SYSTEM</h1>
    </div>
			<nav>
				<ul>
					<li><a href="index.php">HOME &nbsp</a></li>
				</ul>
			</nav>
		</header>
		<section>
			<div class="box">
				<br><br><br><br>
				<h1 style="text-align: center; font-size: 35px;">Welcome to Grocery Store</h1><br><br>
				<p style="text-align: center;font-size: 25px;">The place where you can easily</p><br>
				<p style="text-align: center;font-size: 25px;">Manage your business</p><br>
			</div>
		</div>
		</section>
		<footer>
			<p style="color:rgb(254, 254, 254);  text-align: center; text-emphasis-color: white;">
				<br><br>
				Email: iqramueed3@gmail.com<br>
                Email:aimangohar@gmail.com<br>
				Mobile: +92567*****
			</p>
		</footer>
	</div>
</body>

</html>