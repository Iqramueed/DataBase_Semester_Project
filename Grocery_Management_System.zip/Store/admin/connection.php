<?php
   
   /* make a variable with dollar sign*/
   /*mysqli_connect() function opens a new connection to the MySQL server.*/
    $db=mysqli_connect("localhost","root","","groc_management");
    /* (server name, username, password, database name)*/

 if(!$db)
 {
 	/* If database is not connected correctly*/
 	/*mysqli_connect_error() function returns the error description from the last connection error, if any.

*/
 	die("Connection Failed:" .mysqli_connect_error());
 }

/*echo and print are more or less the same. They are both used to output data to the screen.*/
   echo "Connected Successfully";
    ?>