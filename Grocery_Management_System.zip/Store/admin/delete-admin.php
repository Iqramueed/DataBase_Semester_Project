<?php
   
   include "connection.php"
?>

<!DOCTYPE html>
<html>
<head>
	<title>DELETE DATA</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
	<body>
        <header style="height: 90px;">
            <div class="logo">
                <h1 style="color: white; font-size: 22px;word-spacing: 10px; line-height: 30px;margin-top: 0px;">GROCERY MANAGEMENT SYSTEM</h1>
            </div>
            <!---- navigation part -------------->
            <nav>
                <ul>
                  <li><a href="admin.php">ADMIN</a></li>
                  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">LOGOUT &nbsp</span></a></li>
        
               </ul>
              </nav>
              </header>
              <!-------------- navigation part end -------------->
              <!------------------- FORM FOR deleting data---------->
              
               <div class="box90">
                <h1 style="text-align: center; font-size: 35px;font-family: Lucida Console;"> &nbsp Grocery Management System</h1>
                <h1 style="text-align: center; font-size: 25px;">Delete Form</h1>
              <form name="Deleting" action="" method="post">
                
                <div class="DELETE DATA">
                  <input class="form-control" type="number" name="id" placeholder="Id" required=""> <br>
                 <input class="btn btn-default" type="submit" name="submit" value="delete" style="color: black; width: 70px; height: 30px"> </div>
              </form>
             
            </div>
          </div>
       <?php
           
           if(isset($_POST['submit']))
           {
              mysqli_query($db,"DELETE from admin where id = '$_POST[id]' ;");
           ?>
             <script type="text/javascript">
             alert("Delete Successful.");
             window.location="admin.php"
           </script>
<?php  }

       ?>
        



        </body>
        </html>