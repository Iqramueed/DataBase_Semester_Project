<?php
 include "connection.php"

?>

<!DOCTYPE html>
<html>
<head>
	<title>ADD_USER</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
	<body>
        <header style="height: 90px;">
            <div class="logo">
                <h1 style="color: white; font-size: 22px;word-spacing: 10px; line-height: 30px;margin-top: 0px;">GROCERY MANAGEMENT SYSTEM</h1>
            </div>
            <!---- navigation part -------------->
            <nav>
                <ul>
                  <li><a href="user.php">USER</a></li>
                  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">LOGOUT &nbsp</span></a></li>
        
               </ul>
              </nav>
              </header>
              <!-------------- navigation part end -------------->
              <!------------------- FORM FOR ADDING USER---------->
               <div class="box11">
                <h1 style="text-align: center; font-size: 27px;font-family: Lucida Console;"> &nbsp Grocery Management System</h1>
                <h1 style="text-align: center; font-size: 15px;">Adding User</h1>
              <form name="Adding User" action="" method="post">
                
                <div class="ADD_USER">
                   <input class="form-control" type="number" name="id" placeholder="ID" required=""><br>
                   <input class="form-control" type="text" name="First_Name" placeholder="First Name" required=""> <br>
                   <input class="form-control" type="text" name="Last_Name" placeholder="Last Name" required=""> <br>
                   <input class="form-control" type="text" name="username" placeholder="Username" required=""> <br>
                   <input class="form-control" type="password" name="password" placeholder="Password" required=""> <br>
                    <input class="form-control" type="text" name="email" placeholder="Email" required=""><br>
                  
                 
                  <input class="btn btn-default" type="submit" name="submit" value="Add" style="color: black; width: 70px; height: 30px"> </div>
              </form>
             </div>
          </div>


               <?php

                if(isset($_POST['submit']))
                {

                    mysqli_query($db,"INSERT into user VALUES('$_POST[id]', '$_POST[First_Name]', '$_POST[Last_Name]', '$_POST[username]','$_POST[password]','$_POST[email]');")

                   ?>
                   <script type="text/javascript">
                   alert("User Added Successfully");
                   window.location="user.php"
              </script>

              
              <?php

                }
           
?>
</body>
</html>