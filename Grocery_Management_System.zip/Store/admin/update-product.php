<?php

  include "connection.php"

?>

<!DOCTYPE html>
<html>
<head>
	<title>UPDATE_PRODUCTS</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
	<body>
        <header style="height: 90px;">
            <div class="logo">
                <h1 style="color: white; font-size: 22px;word-spacing: 10px; line-height: 30px;margin-top: 0px;">GROCERY MANAGEMENT SYSTEM</h1>
              </div>
            <!---- navigation part -------------->
            <nav>
                <ul>
                  <li><a href="index.php">HOME</a></li>
                  <li><a href="product.php">PRODUCTS</a></li>
                  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">LOGOUT</span></a></li>
        
               </ul>
              </nav>
              </header>
              <!-------------- navigation part end -------------->
              <!------------------- FORM FOR updating PRODUCTS---------->
               <div class="box12">
                <h1 style="text-align: center; font-size: 27px;font-family: Lucida Console;"> &nbsp Grocery Management System</h1>
                <h1 style="text-align: center; font-size: 15px;">Updating products</h1>
              <form name="Updating products" action="" method="post">
                
                <div class="UPDTAE_PRODUCTS">
                  <input class="form-control" type="number" name="product_id" placeholder="Product Id" required=""> <br>
                  <input class="form-control" type="number" name="quantity" placeholder="product Quantity" required=""> <br>
                  <input class="btn btn-default" type="submit" name="submit" value="Update" style="color: black; width: 70px; height: 30px"> </div>
              </form>
             </div>
          </div>

          <?php
           if(isset($_POST['submit']))
           {
              if(mysqli_query($db,"UPDATE product SET quantity='$_POST[quantity]' WHERE product_id= '$_POST[product_id]';"))
              {
                ?>
                <script type="text/javascript">
                alert("Product Updated Successfully");
                window.location="product.php"
              </script>

              
              <?php
              }
           }

?>
          </body>
</html>