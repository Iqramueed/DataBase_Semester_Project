<?php
   
   include "connection.php"
?>

<!DOCTYPE html>
<html>
<head>
	<title>USERS</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
	<body>
        <header style="height: 90px;">
            <div class="logo">
                <h1 style="color: white; font-size: 22px;word-spacing: 10px; line-height: 30px;margin-top: 0px;">GROCERY MANAGEMENT SYSTEM</h1>
            </div>
            <!---- navigation part -------------->
      <nav>
      <ul>
                 <li><a href="index.php">HOME</a></li>
                  <li><a href="category.php">CATEGORY</a></li>
                  <li><a href="product.php">PRODUCTS</a></li>
                  <li><a href="supplier.php">SUPPLIER</a></li>
                  <li><a href="department.php">DEPARTMENT</a></li>
                  <li><a href="employee.php"> EMPLOYEE</a></li>
                  <li><a href="sale.php"> SALES</a></li>
                  <li><a href="customer.php">CUSTOMER</a></li>
                  <li><a href="user.php">USER</a></li>
                  <li><a href="admin.php">ADMIN</a></li>
                  <li><a href="logout.php"><span class="glyphicon glyphicon-log-out">LOGOUT &nbsp</span></a></li>

       </ul>
      </nav>
      </header>
      <!-------------- navigation part end -------------->
      <!-------------------- side nav bar--------------->
      <!-- Side navigation -->
<!-- The sidebar -->
<nav>
  <ul>
    <a href="add-user.php">&nbsp; &nbsp ADD</a>
    <a href="delete.php">DELETE</a>
    <a href="update-user.php">UPDATE</a>
  </ul>
</nav>

        
       <!----------------------------- SEARCH BAR ---------------->
   <section>
    
         	<form class = "navbar-form" method = "post" name="form1">
       		  <div class="srch">
       			     <input calss="form-control" type ="text" name="search" placeholder="search users.." required="">
       			    <button style="background-color:#6db6b9e6;" type="submit" name="submit" class="btn btn-default">
       				     <span class="glyphicon glyphicon-search"></span>
       		        </button>
       	        </div>
            </form>
            <br><br>
       
		<!--<h2 style="color: rgb(0, 0, 0);float:right; font-size: 20px;word-spacing: 10px; line-height: 20px;margin-top: 0px;">LIST OF SUPPLIER:</h2>-->
        <br><br>
       <?php

        if(isset($_POST['submit']))
           {
               $g=mysqli_query($db,"SELECT * from `user` where name like '%$_POST[search]%'");

               if(mysqli_num_rows($g)==0 )
               {
                   echo "Sorry! No supplier is found. Try searching again.";
               }

               else
               {
                   echo "<table class='table table-bordered table-hover'>";
                    echo "<tr style= 'background-color:#6db6b9e6;'>";
                    echo "<th>"; echo "USER ID"; echo "</th>";
                    echo "<th>"; echo "FIRST NAME"; echo "</th>";
                    echo "<th>"; echo "LAST NAME"; echo "</th>";
                    echo "<th>"; echo "USERNAME"; echo "</th>";
                    echo "<th>"; echo "PASSWORD"; echo "</th>";
                    echo "<th>"; echo "EMAIL"; echo "</th>";


            echo"</tr>";

            /* while loop to fetch all the rows from the table*/

             while($row=mysqli_fetch_assoc($g))
             {
              /* tr is the table row element*/
              /* td defines a cell in the table*/
              echo "<tr>";
              echo "<td>"; echo $row['id']; echo "</td>";
              echo "<td>"; echo $row['First_Name']; echo "</td>";
              echo "<td>"; echo $row['Last_Name']; echo "</td>";
              echo "<td>"; echo $row['username']; echo "</td>";
              echo "<td>"; echo $row['password']; echo "</td>";
              echo "<td>"; echo $row['email']; echo "</td>";

                   echo "</tr>";
         }

           echo "</table>";
       }

               }

           else
           {
              $result=mysqli_query($db,"SELECT * from `user`;");
              echo "<table class='table table-bordered table-hover'>";
              echo "<tr style= 'background-color:#6db6b9e6;'>";
              echo "<th>"; echo "USER ID"; echo "</th>";
              echo "<th>"; echo "FIRST NAME"; echo "</th>";
              echo "<th>"; echo "LAST NAME"; echo "</th>";
              echo "<th>"; echo "USERNAME"; echo "</th>";
              echo "<th>"; echo "PASSWORD"; echo "</th>";
              echo "<th>"; echo "EMAIL"; echo "</th>";


        echo"</tr>";

        /* while loop to fetch all the rows from the table*/

         while($row=mysqli_fetch_assoc($result))
         {
          /* tr is the table row element*/
          /* td defines a cell in the table*/
          echo "<tr>";
          echo "<td>"; echo $row['id']; echo "</td>";
          echo "<td>"; echo $row['First_Name']; echo "</td>";
          echo "<td>"; echo $row['Last_Name']; echo "</td>";
          echo "<td>"; echo $row['username']; echo "</td>";
          echo "<td>"; echo $row['password']; echo "</td>";
          echo "<td>"; echo $row['email']; echo "</td>";

          

               echo "</tr>";
         }

           echo "</table>";
       }
?> 
           
          
    </section>
</body>
</html>