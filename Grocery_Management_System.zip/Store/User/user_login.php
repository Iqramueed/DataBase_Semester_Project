<?php
 include "connection.php";
 session_start();
 ?>

<!DOCTYPE html>
<html>
<head>

  <title>User Login</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  
  <style type="text/css">
    section
    {
      margin-top: -5px;
    }
  </style>
  </head>
  <body>  
    <header style="height: 90px;">
  
<div class="logo">
      <h1 style="color: white; font-size: 22px;word-spacing: 20px; line-height: 18px;margin-top: 3px;">GROCERY MANAGEMENT SYSTEM</h1>
    </div>

      <nav>
        <ul>
         <li><a href="index.php">HOME</a></li>
         <li><a href="contact.php">CONTACT</a></li>
         <li><a href="about.php">ABOUT_US &nbsp</a></li>
        <!--<li><a href="category.php">CATEGORY</a></li>
          <li><a href="product.php">PRODUCTS</a></li>
          <li><a href="supplier.php">SUPPLIER</a></li>
          <li><a href="department.php">DEPARTMENT</a></li>
          <li><a href="employee.php"> EMPLOYEE</a></li>
          <li><a href="sale.php"> SALES</a></li>
          <li><a href="customer.php">CUSTOMER</a></li>
          <li><a href="user_login.php"><span class="glyphicon glyphicon-log-in">LOGIN</span></a></li>
          <li><a href="registration.php"><span class="glyphicon glyphicon-user">SIGN_UP</span></a></li>-->
        </ul>
      </nav>
    </header>
<section>
  <div class="log_img">
    <br> <br><br>
    <div class="box1">
        <h1 style="text-align: center; font-size: 27px;font-family:'Lucida Sans Unicode';">Grocery Management System</h1>
        <h1 style="text-align: center; font-size: 20px;">User Login Form</h1>
      <form name="login" action="" method="post">
        <br><br>
        <div class="login">
          <input type="text" name="username" placeholder="Username" required=""> <br><br>
          <input type="password" name="password" placeholder="Password" required=""> <br><br>
          
          
         <!-- <button>Login</button></div>-->
         <input class="btn btn-default" type="submit" name="submit" value="Log In" style="color: black; width: 70px; height: 30px"> </div>
      </form>
      <p style="color: white; padding-left: 15px;">
        <br><br>
        <a style="color:white;" href="">Forgot password?</a> <a style="color: white;" href="update-user.php">Change</a> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
        New to this website?<a style="color: white;" href="registration.php">Sign Up</a>
      </p>
    </div>
  </div>
</section>
<?php

    if(isset($_POST['submit']))
    {
      $count=0;
      $res=mysqli_query($db,"SELECT * FROM `user` WHERE username='$_POST[username]' && password='$_POST[password]';");
      
      $row= mysqli_fetch_assoc($res);
      $count=mysqli_num_rows($res);

      if($count==0)
      {
        ?>
              <!--
              <script type="text/javascript">
                alert("The username and password doesn't match.");
              </script> 
              -->
          <div class="alert alert-danger" style="width: 600px; margin-left: 370px; background-color: #de1313; color: white">
            <strong>The username and password doesn't match</strong>
          </div>    
        <?php
      }
      else
      {
        $_SESSION['login_user'] = $_POST['username'];

        ?>
          <script type="text/javascript">
            window.location="index.php"
          </script>
        <?php
      }
    }

  ?>


</body>
</html>
