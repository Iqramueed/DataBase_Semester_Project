<?php
    session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<title>
		GROCERY MANAGEMENT SYSTEM
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<style type="text/css">
	nav
	{
		float: right;
		word-spacing: 30px;
		padding: 20px;
		color:black;
	}
	nav li 
	{
		display: inline-block;
		line-height: 40px;
	}
</style>
</head>


<body>
	<div class="wrapper">
		<header>
			<div class="logo">
			 <h1 style="color: white; font-size: 22px;word-spacing: 30px; line-height: 18px;margin-top: 10px;">GROCERY MANAGEMENT SYSTEM</h1>
		</div>
          <?php
                if(isset($_SESSION['login_user']))
                {?>
                         <nav>
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="product.php">PRODUCTS</a></li>
					<li><a href="logout.php">LOGOUT</a></li>
					<li><a href="about.php"> ABOUT</a></li>
					<li><a href="">
						<div style="color:white">
							<?php
					 echo "Welcome " .$_SESSION['login_user'];
					 ?>
				</div>
				</a></li>
				</ul>
			</nav>
               
               <?php
                }
             else
             {
             	?>
             	<nav>
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="user_login.php">USER_LOGIN</a></li>
					<li><a href="about.php"> ABOUT</a></li>
					<li>
					
				</ul>
			</nav>


           <?php  }

          ?>
			
		</header>
		<section>
		<div class="sec_img">
			<br><br><br>
			<div class="box">
				<br><br><br><br>
				<h1 style="text-align: center; font-size: 35px;">Welcome to Grocery Store</h1><br><br>
				<h1 style="text-align: center;font-size: 25px;">Opens at: 09:00 </h1><br>
				<h1 style="text-align: center;font-size: 25px;">Closes at: 15:00 </h1><br>
				<h1 style="text-align: center;font-size: 25px;">Log In As: </h1><br>
				<input style="margin-left:50px; width:18px;" type="radio" name="user" id="user" value="user">
				<label>User</label>
				<input style="margin-left:50px; width:18px;" type="radio" name="admin" id="admin" value="admin">
				<label>Admin</label>
			</div>
		</div>
		</sectio>
	</div>
</body>

</html>